The .exe is located in "Blater boi_1_0_0_2/bin/Release/Blaster Boi.exe"

